name = input("Gib deinem Haustier einen Namen: ")  
alter = int(input("Wie alt ist dein Haustier? "))
gesundheit = 30
energie = 20
angriff = 20
verteidigung = 20
erfahrung = 0
schlaeft = False
menü = ["Zahl eingeben", "Füttern", "Spielen", "Trainieren", "Ausruhen"]
auswahl = 0
menuzaehler = True

print(f"{name} ist {alter} Jahre alt. (Gesundheit: {gesundheit}, Energie: {energie}, Erfahrung: {erfahrung})")

def check(x, y):
    if x < 25 and y < 25:
        return "Der Zustand ist schlecht"
    elif x < 25 or y < 25:
        return "Der Zustand ist mittelmäßig"
    else:
        return "Der Zustand ist gut"

eingabe = int(input("Gib eine Zahl ein.\n1: Medizinische Versorgung\n2: Schlafen legen\n"))

def verbessern(x):
    x += 10
    return x

if(eingabe == 1):
     gesundheit = verbessern(gesundheit)
elif(eingabe == 2):
    energie = verbessern(energie)
else:
    print("Ungültige Eingabe")

if not schlaeft and (gesundheit < 20 or energie < 20):
    schlaeft = True
    gesundheit += 10
    energie += 10
    print(f"{name} ist vor Erschöpfung eingeschlafen.")
elif schlaeft and gesundheit >= 20 and energie >= 20:
    schlaeft = False
    print(f"{name} ist ausgeruht aufgewacht.")
else:
    print(f"{name} fühlt sich gut.")

while menuzaehler:    
    auswahl = int(input("Gib eine Zahl ein."))
    if auswahl == 0:
        print(menü[0])
        auswahl = int(input("Gib eine Zahl ein."))
    if auswahl == 1:
        print(menü[1])
        auswahl = int(input("Gib eine Zahl ein."))
    if auswahl == 2:
        print(menü[2])
        auswahl = int(input("Gib eine Zahl ein."))
    if auswahl== 3:
        print(menü[3])
        break
    elif auswahl < 0 or auswahl > 3:
        print("Falsche Eingabe")