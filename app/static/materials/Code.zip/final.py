name = input("Gib deinem Haustier einen Namen: ")
alter = int(input("Wie alt ist dein Haustier? "))
gesundheit = 30
energie = 20
angriff = 20
verteidigung = 20
erfahrung = 0
schlaeft = False
menü = ["Zahl eingeben", "Füttern", "Spielen", "Trainieren", "Kämpfen"]
auswahl = 0
menuzaehler = True

print(f"{name} ist {alter} Jahre alt. (Gesundheit: {gesundheit}, Energie: {energie}, Erfahrung: {erfahrung})")

def check(x, y):
    if x < 25 and y < 25:
        return "Der Zustand ist schlecht"
    elif x < 25 or y < 25:
        return "Der Zustand ist mittelmäßig"
    else:
        return "Der Zustand ist gut"

eingabe = int(input("Gib eine Zahl ein.\n1: Medizinische Versorgung\n2: Schlafen legen\n"))

def verbessern(x):
    return x + 10

if eingabe == 1:
     gesundheit = verbessern(gesundheit)
elif eingabe == 2:
    energie = verbessern(energie)
else:
    print("Ungültige Eingabe")

if not schlaeft and (gesundheit < 20 or energie < 20):
    schlaeft = True
    gesundheit += 10
    energie += 10
    print(f"{name} ist vor Erschöpfung eingeschlafen.")
elif schlaeft and gesundheit >= 20 and energie >= 20:
    schlaeft = False
    print(f"{name} ist ausgeruht aufgewacht.")
else:
    print(f"{name} fühlt sich gut.")

def kampf(angriff):
    gegner_angriff = 25
    gegner_verteidigung = 15
    schaden = 0  # Initialisierung von schaden

    print("Ein wilder Gegner taucht auf!")
    while True:
        print("Was möchtest du tun?")
        print("1: Normale Attacke")
        print("2: Starke Attacke")
        print("3: Verteidigen")
        print("4: Fliehen")
        aktion = int(input("Wähle eine Aktion: "))

        if aktion == 1:
            schaden = angriff - gegner_verteidigung
            if schaden < 0:
                schaden = 0
            print(f"{name} führt eine normale Attacke aus und fügt dem Gegner {schaden} Schaden zu.")
        elif aktion == 2:
            schaden = angriff * 2 - gegner_verteidigung
            if schaden < 0:
                schaden = 0
            print(f"{name} führt eine starke Attacke aus und fügt dem Gegner {schaden} Schaden zu.")
        elif aktion == 3:
            print(f"{name} verteidigt sich und erhöht seine Verteidigung.")
            angriff += 5
        elif aktion == 4:
            print(f"{name} ist geflohen!")
            return  # Verlasse die Funktion kampf(), um den Kampf zu beenden
        else:
            print("Ungültige Eingabe.")
            continue  # Springe zurück zum Anfang der Schleife, um erneut eine Aktion auszuwählen

        if schaden >= gegner_angriff:
            print("Der Gegner wurde besiegt!")

        # Zeige das Kampfmenü erneut an, außer wenn der Gegner besiegt wurde oder der Spieler geflohen ist
        if aktion != 4 and schaden < gegner_angriff:
            continue  # Springe zurück zum Anfang der Schleife, um erneut eine Aktion auszuwählen
        else:
            break  # Beende die Schleife und somit die Funktion kampf(), um den Kampf zu beenden

while True:
    print("Menü:")
    print("1:", menü[1])
    print("2:", menü[2])
    print("3:", menü[3])
    print("4:", menü[4])
    auswahl = int(input(menü[0]))
    if auswahl == 0:
        print(menü[0])
        break
    elif auswahl == 1:
        print(menü[1])
    elif auswahl == 2:
        print(menü[2])
    elif auswahl == 3:
        print(menü[3])
    elif auswahl == 4:
        kampf(angriff)
    else:
        print("Falsche Eingabe")
